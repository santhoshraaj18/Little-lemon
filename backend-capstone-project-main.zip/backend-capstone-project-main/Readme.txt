API endpoints:
    /api/                        

    /api/menu-items/            
    /api/menu-items/2             

    /api/booking/tables/        

    [NOTE: non-superuser will return them self. super user will return all user]
    /auth/users/                

    /api/api-token-auth/           

